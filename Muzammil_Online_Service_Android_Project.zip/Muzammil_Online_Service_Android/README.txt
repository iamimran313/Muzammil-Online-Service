Muzammil Online Service - Android App Project

Features:
- Professional mobile dashboard
- Customer management with local storage
- Fees, payment and due tracking
- Professional JPG receipt generation
- Government / banking portal shortcuts with Roman Hindi descriptions
- MahaSarathi English landing page
- Kotak DBT/Aadhaar seeding and BC/AePS information
- Backup JSON
- Shop settings: Muzammil Online Service / 7798313882

How to build:
1. Install Android Studio (recent version).
2. Open this folder in Android Studio.
3. Let Gradle sync/download Android plugin dependencies.
4. Run on Android phone or emulator.
5. Build > Build APK(s).

Note: This environment does not have the Android SDK/Gradle build toolchain, so this package is the complete Android Studio source project, not a precompiled APK.
