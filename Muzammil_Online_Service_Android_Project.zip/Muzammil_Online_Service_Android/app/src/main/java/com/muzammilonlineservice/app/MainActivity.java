package com.muzammilonlineservice.app;
import android.app.*;import android.os.*;import android.webkit.*;import android.graphics.Color;import android.view.*;
public class MainActivity extends Activity{
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.setBackgroundColor(Color.WHITE); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setSupportZoom(false); w.setWebViewClient(new WebViewClient()); w.setDownloadListener((url,user,content,mt,len)->{}); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
